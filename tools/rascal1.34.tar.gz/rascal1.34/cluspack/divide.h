/**************************************/
/*                                    */
/*Clustering par divisions successives*/
/*                                    */
/**************************************/

void divide(int nb_individus,int nb_dimensions,int *nb_clusters,individu_t **individus,
	    int type_donnees,int clustering_method,int nb_clusters_selection,
	    int donnees_normalisees,int type_densite);
     
